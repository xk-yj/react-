import React from 'react';
import Input from '..'

export default function InputDemo1() {
    return (
        <div >
            <Input />
        </div>
    )
}
