import React from 'react'
import Input from '..'

export default function index2() {
  return (
    <div>
      <Input defaultValue="禁用" disabled={true} />
    </div>
  )
}
