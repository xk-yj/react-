import React from 'react'
import Input from '..'

export default function index5() {
    return (
        <div>
            <Input bordered={true} defaultValue="输入框边框" />
        </div>
    )
}
