import React from 'react'
import Input from '..'

export default function InputDemo3() {
    return (
        <div>
            <Input type={'password'} defaultValue="请输入密码"></Input>
        </div>
    )
}
